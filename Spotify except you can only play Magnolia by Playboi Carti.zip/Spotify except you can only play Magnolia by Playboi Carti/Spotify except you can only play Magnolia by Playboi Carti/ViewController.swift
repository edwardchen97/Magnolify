//
//  ViewController.swift
//  Spotify except you can only play Magnolia by Playboi Carti
//
//  Created by Edward Chen on 2017-07-12.
//  Copyright © 2017 booLEAN. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate {

    var player = AVAudioPlayer()
    var play = false
    var shuffle = false
    var replay = false
    let audioPath = Bundle.main.path(forResource: "Magnolia - Carti", ofType: "mp3")
    var timer = Timer()

    func updateScrubber(){
        
        scrubber.value = Float(player.currentTime)
        
    }
    
    @IBOutlet var playPauseImage: UIButton!
    
    @IBAction func PlayPause(_ sender: Any) {
        
        if play == false{
            
            player.play()
            
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.updateScrubber), userInfo: nil, repeats: true)
            
            play = true
            
            playPauseImage.setImage(UIImage(named: "pause.png"), for: .normal)
            
        } else{
            
            player.pause()
            
            timer.invalidate()
            
            play = false
            
            playPauseImage.setImage(UIImage(named: "play-button.png"), for: .normal)
            
            
        }
        
    }
    
    @IBOutlet var shuffleImage: UIButton!
    
    @IBAction func shuffle(_ sender: Any) {
        
        if shuffle == false{
            
            shuffleImage.setImage(UIImage(named: "shuffle-green.png"), for: .normal)
            
            shuffle = true
            
            
            player.numberOfLoops = -1
            
        } else{
            
            shuffleImage.setImage(UIImage(named: "shuffleWhite.png"), for: .normal)
            
            shuffle = false
            
            player.numberOfLoops = 0
        }
        
        
    }
    
    @IBOutlet var replayImage: UIButton!
    
    @IBAction func replay(_ sender: Any) {
        
        if replay == false{
            
            replayImage.setImage(UIImage(named: "repeat-green.png"), for: .normal)
            
            replay = true
            
            player.numberOfLoops = -1
            
        } else{
            
            replayImage.setImage(UIImage(named: "repeatWhite.png"), for: .normal)
            
            replay = false
            
            player.numberOfLoops = 0
        }
    }
    
    
    
    @IBAction func next(_ sender: Any) {
        
        scrubber.value = 0
        
        player.currentTime = 0
        
        player.play()
        
        playPauseImage.setImage(UIImage(named: "pause.png"), for: .normal)
        
    }
    
    @IBAction func previous(_ sender: Any) {
        
        
        scrubber.value = 0
        
        player.currentTime = 0
        
        player.play()
        
        playPauseImage.setImage(UIImage(named: "pause.png"), for: .normal)
        
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        
        playPauseImage.setImage(UIImage(named: "play-button.png"), for: .normal)
    }
    
    @IBAction func scrubberMoved(_ sender: Any) {
        
        player.currentTime = TimeInterval(scrubber.value)
        
    }
 
    
    @IBOutlet var scrubber: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        scrubber.setThumbImage(UIImage(named: "Oval.png"), for: .normal)
        
        do{
            
            try player = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
            
            scrubber.maximumValue = Float(player.duration)
            
        } catch{
            
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

